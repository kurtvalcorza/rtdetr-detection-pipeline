"""Review probes for tutorials/rtdetr_detection_colab.ipynb (prefix RTD), reviewed at 7508f6c.

CPU only (CUDA_VISIBLE_DEVICES=-1). Executes the notebook's OWN code cells, in order, in one namespace,
from a scratch working directory that holds a pre-staged copy of the 4-file pinned snapshot (digests are
re-verified by the notebook's verify_snapshot). DIMER_NOTEBOOK_CI_PREINSTALLED=1 skips the pip cell's
install (the environment is torch 2.13.0+cpu / pillow 12.3.0, NOT the 2.14.0 / 11.3.0 pins), so this is
not a Colab run and not a clean-runtime run.

Usage: python run_probes.py <notebook.ipynb> <workdir> <results.json> [probe ...]
Probes: static, default, rerun, shortcut, overlap, byod (default: all, in that order).
results.json is rewritten after every probe (write-immediately).
"""
from __future__ import annotations

import contextlib
import io
import json
import os
import sys
import time
import traceback
from pathlib import Path

NB, WORK, OUT = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve(), Path(sys.argv[3]).resolve()
SELECTED = sys.argv[4:] or ["static", "default", "rerun", "shortcut", "overlap", "byod"]
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
os.environ.setdefault("MPLBACKEND", "Agg")

nb = json.loads(NB.read_text(encoding="utf-8"))
CELLS = nb["cells"]
CODE = {i: "".join(c["source"]) for i, c in enumerate(CELLS) if c["cell_type"] == "code"}
results: dict = json.loads(OUT.read_text()) if OUT.exists() else {}
NS: dict = {"__name__": "__main__"}


def save() -> None:
    OUT.write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")


def run_cell(i: int, ns: dict | None = None) -> dict:
    ns = NS if ns is None else ns
    buf = io.StringIO()
    t0 = time.perf_counter()
    status, err = "ok", None
    try:
        with contextlib.redirect_stdout(buf):
            exec(compile(CODE[i], f"<cell {i}>", "exec"), ns)
    except BaseException as exc:  # noqa: BLE001
        status, err = "error", f"{type(exc).__name__}: {exc}"
        traceback.print_exc()
    return {"cell": i, "status": status, "error": err, "seconds": round(time.perf_counter() - t0, 1),
            "stdout_tail": buf.getvalue()[-2500:]}


def probe_static() -> dict:
    import re
    out = {"nbformat": nb.get("nbformat"), "n_cells": len(CELLS), "n_code": len(CODE),
           "metadata_dimer": nb["metadata"].get("dimer"), "compile_errors": {}, "persisted_outputs": 0}
    for i, src in CODE.items():
        try:
            compile(src, f"<cell {i}>", "exec")
        except SyntaxError as exc:
            out["compile_errors"][i] = str(exc)
    out["persisted_outputs"] = sum(len(c.get("outputs", [])) for c in CELLS if c["cell_type"] == "code")
    text = {i: "".join(c["source"]) for i, c in enumerate(CELLS)}
    out["google_colab_cells"] = [i for i, s in text.items() if "google.colab" in s and CELLS[i]["cell_type"] == "code"]
    out["byod_records_placeholder"] = [i for i, s in text.items() if "byod_records = []" in s]
    out["restart_guard_cells"] = [i for i, s in text.items() if "Restart the runtime" in s]
    out["infrastructure_labels"] = [i for i, s in text.items() if re.search(r"Infrastructure", s)]
    out["cellView_form"] = [i for i, c in enumerate(CELLS) if c.get("metadata", {}).get("cellView") == "form"]
    out["guided_markers"] = {k: [i for i, s in text.items() if k.lower() in s.lower()] for k in
                             ("How to use this notebook", "Roadmap", "Glossary", "Predict", "What to notice",
                              "Expected result", "Check your reasoning", "Troubleshooting", "<details")}
    out["hardcoded_claims"] = {
        "interp_iou_0.91_0.97": [i for i, s in text.items() if "0.91" in s and "0.97" in s],
        "trainable_19.3M_42.7M": [i for i, s in text.items() if "19.3" in s and "42.7" in s],
        "cpu_30_50s_t4_1_2s": [i for i, s in text.items() if "30–50 s" in s or "30-50 s" in s],
        "baseline_no_false_positives": [i for i, s in text.items() if "no false positives" in s],
        "match_exactly": [i for i, s in text.items() if "match exactly" in s or "identically" in s],
        "non_empty_coordinates": [i for i, s in text.items() if "non-empty coordinates" in s],
    }
    out["env_vars_read"] = sorted(set(re.findall(r"os\.environ\.get\('([A-Z_]+)'", "\n".join(CODE.values()))))
    out["form_fields"] = {i: re.findall(r"^(\w+) = .*# @param", s, flags=re.M) for i, s in CODE.items()
                          if "# @param" in s}
    return out


def probe_default() -> dict:
    os.chdir(WORK)
    rows, t0 = [], time.perf_counter()
    for i in sorted(CODE):
        if i == 29:  # BYOD cell is run separately in probe_byod with its defaults
            rows.append(run_cell(i))
            continue
        r = run_cell(i)
        rows.append(r)
        print(f"cell {i}: {r['status']} {r['seconds']}s {r['error'] or ''}", file=sys.stderr, flush=True)
        if r["status"] != "ok":
            break
    ns = NS
    out = {"cells": rows, "wall_seconds": round(time.perf_counter() - t0, 1)}
    with contextlib.suppress(Exception):
        import torch, transformers, numpy, PIL  # noqa: E401
        out["runtime"] = {"python": sys.version.split()[0], "torch": torch.__version__,
                          "transformers": transformers.__version__, "numpy": numpy.__version__,
                          "PIL": PIL.__version__, "cuda": torch.cuda.is_available()}
    with contextlib.suppress(Exception):
        out["coco_detections"] = [(d["label"], round(d["score"], 3)) for d in ns["coco_result"]["detections"]]
        out["coco_iou"] = {m["reference"]: round(m["value"], 3) for m in ns["coco_report"]["metrics"]}
        out["degenerate"] = ns["degenerate"]
        out["dataset_manifest"] = ns["dataset_manifest"]
        out["split"] = {"train": len(ns["train_records"]), "held_out": len(ns["held_out"]),
                        "held_out_classes": sorted({l for r in ns["held_out"] for l in r["labels"]})}
        b, a = ns["baseline"], ns["adapted"]
        out["baseline"] = {k: round(b[k], 4) for k in ("ap", "ap50", "ap75")} | {
            "per_class_ap50": b["per_class_ap50"], "detections_before_cap": b["detections_before_cap"]}
        out["run"] = {k: ns["run"][k] for k in ("trainable_parameters", "total_parameters", "epoch_losses")}
        out["adapted"] = {k: round(a[k], 4) for k in ("ap", "ap50", "ap75")} | {
            "per_class_ap50": a["per_class_ap50"]}
        out["new_data_rows"] = ns["new_data_rows"]
        out["reload_compared_detections"] = len(ns["det_orig"])
        out["result_json_keys"] = sorted(json.loads((WORK / "outputs" / "rtdetr_detection_result.json")
                                                    .read_text())["adaptation"].keys())
        out["outputs"] = sorted(p.name for p in (WORK / "outputs").iterdir())
        out["csv_rows_images"] = sorted({line.split(",")[0] for line in (WORK / "outputs" / "rtdetr_detection_detections.csv")
                                         .read_text().splitlines()[1:]})
    return out


def probe_rerun() -> dict:
    """Learner changes one form value in Section 8 and reruns only that cell, then Section 9 (as a learner would)."""
    ns = NS
    if "adapter" not in ns:
        return {"skipped": "default probe did not reach the adapter"}
    adapter = ns["adapter"]
    before_frozen = all(not p.requires_grad for p in adapter.model.model.backbone.parameters())
    src19 = CODE[19].replace("FREEZE_BACKBONE = True", "FREEZE_BACKBONE = False")
    buf = io.StringIO()
    t0 = time.perf_counter()
    with contextlib.redirect_stdout(buf):
        exec(compile(src19, "<cell 19 FREEZE_BACKBONE=False>", "exec"), ns)
    secs = round(time.perf_counter() - t0, 1)
    after_frozen = all(not p.requires_grad for p in adapter.model.model.backbone.parameters())
    r21 = run_cell(21)
    a = ns["adapted"]
    return {"backbone_frozen_before": before_frozen, "reported_freeze_backbone": ns["run"]["freeze_backbone"],
            "backbone_actually_frozen_after_rerun": after_frozen,
            "trainable_parameters_reported": ns["run"]["trainable_parameters"],
            "rerun_epoch_losses": [round(x, 4) for x in ns["run"]["epoch_losses"]],
            "seconds": secs, "cell21": r21["status"],
            "adapted_after_rerun": {k: round(a[k], 4) for k in ("ap", "ap50", "ap75")},
            "baseline_column_still": {k: round(ns["baseline"][k], 4) for k in ("ap", "ap50")}}


def _heuristic_detect(image):
    """Non-learned detector: red-pixel blobs per fixed generator slot; class from red fill ratio and shape."""
    import numpy as np
    arr = np.asarray(image.convert("RGB")).astype(int)
    r, g, b = arr[..., 0], arr[..., 1], arr[..., 2]
    red = (r > 150) & (g < 80) & (b < 80)
    dets = []
    H, W = red.shape
    for cy, cx in [(y, x) for y in (150, 400) for x in (140, 360, 560)]:
        y0, y1, x0, x1 = max(0, cy - 110), min(H, cy + 110), max(0, cx - 110), min(W, cx + 110)
        win = red[y0:y1, x0:x1]
        if win.sum() < 200:
            continue
        ys, xs = np.nonzero(win)
        bx0, by0, bx1, by1 = xs.min() + x0, ys.min() + y0, xs.max() + x0 + 1, ys.max() + y0 + 1
        area = (bx1 - bx0) * (by1 - by0)
        fill = win.sum() / max(area, 1)
        # stop: solid red octagon (high fill). yield: red outline triangle, apex at bottom.
        # speed limit: red ring (circle).
        if fill > 0.45:
            label = "stop-sign"
        else:
            # triangle: red mass concentrated in top rows (base at top)
            sub = red[by0:by1, bx0:bx1]
            top = sub[: max(1, sub.shape[0] // 4)].sum()
            bottom = sub[-max(1, sub.shape[0] // 4):].sum()
            label = "yield-sign" if top > 2.0 * bottom else "speed-limit-sign"
        dets.append({"box": [float(bx0), float(by0), float(bx1), float(by1)], "label": label, "score": float(fill)})
    return dets


def probe_shortcut() -> dict:
    """Score a non-learned colour/shape heuristic on the SAME held-out split with the notebook's average_precision."""
    ns = NS
    if "held_out" not in ns:
        # Rebuild the data path without the model.
        for i in (5, 7):
            run_cell(i)
        ns["records"] = ns["sign_dataset"](40, seed=0)
        ns["train_records"], ns["held_out"] = ns["split_dataset"](ns["records"], train_fraction=0.75, seed=0)
    preds = [_heuristic_detect(r["image"]) for r in ns["held_out"]]
    m = ns["average_precision"](preds, ns["held_out"], ns["SIGN_CLASSES"])
    new = ns["sign_dataset"](3, seed=99)
    mnew = ns["average_precision"]([_heuristic_detect(r["image"]) for r in new], new, ns["SIGN_CLASSES"])
    return {"heuristic": "red-pixel blob per fixed slot; class by fill ratio / top-vs-bottom red mass; no learning",
            "held_out": {k: round(m[k], 4) for k in ("ap", "ap50", "ap75")} | {"per_class_ap50": m["per_class_ap50"]},
            "new_seed99": {k: round(mnew[k], 4) for k in ("ap", "ap50", "ap75")}}


def probe_overlap() -> dict:
    """How close are held-out / new-seed images to training images? Layout = set of (slot, class)."""
    ns = NS
    if "held_out" not in ns:
        probe_shortcut()
    import numpy as np
    slots = [(x, y) for y in (150, 400) for x in (140, 360, 560)]

    def layout(rec):
        out = []
        for box, lab in zip(rec["boxes"], rec["labels"], strict=True):
            cx, cy = (box[0] + box[2]) / 2, (box[1] + box[3]) / 2
            s = min(range(6), key=lambda k: (slots[k][0] - cx) ** 2 + (slots[k][1] - cy) ** 2)
            out.append((s, lab))
        return frozenset(out)

    train_layouts = {layout(r) for r in ns["train_records"]}
    ho = [layout(r) in train_layouts for r in ns["held_out"]]
    new = ns["sign_dataset"](3, seed=99)
    nw = [layout(r) in train_layouts for r in new]
    # pixel distance to nearest training image (mean abs diff, 0-255), vs typical train-train distance
    def arr(r):
        return np.asarray(r["image"].resize((160, 160))).astype(np.float32)
    T = [arr(r) for r in ns["train_records"]]
    def nearest(x):
        return float(min(np.abs(x - t).mean() for t in T))
    return {"held_out_layout_seen_in_train": f"{sum(ho)}/{len(ho)}",
            "new_seed99_layout_seen_in_train": f"{sum(nw)}/{len(nw)}",
            "held_out_nearest_train_mad": [round(nearest(arr(r)), 1) for r in ns["held_out"]],
            "new_nearest_train_mad": [round(nearest(arr(r)), 1) for r in new],
            "train_vs_train_nearest_mad_first5": [round(min(float(np.abs(T[i] - T[j]).mean()) for j in range(len(T)) if j != i), 1) for i in range(5)]}


def probe_byod() -> dict:
    ns = NS
    for i in (5, 7):
        if "validate_dataset" not in ns:
            run_cell(i)
    out = {}
    # 1. BYOD dataset branch exactly as shipped: flip only the form value.
    src = CODE[29].replace("USE_BYOD_DATASET = False", "USE_BYOD_DATASET = True")
    ns.setdefault("threshold", 0.3); ns.setdefault("EPOCHS", 3); ns.setdefault("SEED", 0)
    ns.setdefault("BATCH_SIZE", 4); ns.setdefault("LEARNING_RATE", 1e-4)
    from pathlib import Path as _P
    ns.setdefault("OUTPUTS", _P("outputs"))
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            exec(compile(src, "<cell 29 USE_BYOD_DATASET=True>", "exec"), ns)
        out["dataset_branch_as_shipped"] = "ran"
    except Exception as exc:  # noqa: BLE001
        out["dataset_branch_as_shipped"] = f"{type(exc).__name__}: {exc}"
    # 2. BYOD image branch outside Colab.
    src = CODE[29].replace("USE_BYOD_IMAGE = False", "USE_BYOD_IMAGE = True")
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            exec(compile(src, "<cell 29 USE_BYOD_IMAGE=True>", "exec"), ns)
        out["image_branch_outside_colab"] = "ran"
    except Exception as exc:  # noqa: BLE001
        out["image_branch_outside_colab"] = f"{type(exc).__name__}: {exc}"
    # 3. validate_dataset contract probes.
    vd, img = ns["validate_dataset"], ns["blank_scene"]()
    cases = {
        "zero_area_box": [{"image": img, "boxes": [[10, 10, 10, 10]], "labels": ["stop-sign"]}],
        "nan_box": [{"image": img, "boxes": [[float("nan"), 0, 10, 10]], "labels": ["stop-sign"]}],
        "image_without_boxes": [{"image": img, "boxes": [], "labels": []}],
        "only_one_class_of_three": [{"image": img, "boxes": [[0, 0, 50, 50]], "labels": ["stop-sign"]}] * 4,
        "duplicate_image_records": [{"image": img, "boxes": [[0, 0, 50, 50]], "labels": ["stop-sign"]}] * 2,
        "path_string_image": [{"image": "/x.png", "boxes": [[0, 0, 5, 5]], "labels": ["stop-sign"]}],
        "unknown_label": [{"image": img, "boxes": [[0, 0, 5, 5]], "labels": ["cat"]}],
    }
    out["validate_dataset"] = {}
    for name, recs in cases.items():
        try:
            m = vd(recs, ["stop-sign", "yield-sign", "speed-limit-sign"])
            out["validate_dataset"][name] = f"accepted ({m['observed_classes']})"
        except Exception as exc:  # noqa: BLE001
            out["validate_dataset"][name] = f"{type(exc).__name__}: {exc}"
    # 4. split of a 4-record single-image-per-class set: does held-out cover all classes?
    recs = ns["sign_dataset"](8, seed=3)
    tr, ho = ns["split_dataset"](recs, train_fraction=0.75, seed=0)
    out["small_byod_split"] = {"train": len(tr), "held_out": len(ho),
                               "held_out_classes": sorted({l for r in ho for l in r["labels"]})}
    # 5. split with 2 records -> 1 / 1; with 3 -> 2/1 (no minimum stated)
    out["byod_minimum_stated_in_notebook"] = any("minimum" in "".join(c["source"]).lower() for c in CELLS[26:30])
    return out


for name in SELECTED:
    print(f"== probe {name}", file=sys.stderr, flush=True)
    t0 = time.perf_counter()
    try:
        results[name] = globals()[f"probe_{name}"]()
    except Exception as exc:  # noqa: BLE001
        results[name] = {"error": f"{type(exc).__name__}: {exc}", "trace": traceback.format_exc()[-2000:]}
    results.setdefault("_timing", {})[name] = round(time.perf_counter() - t0, 1)
    save()
print(json.dumps({k: results[k] for k in SELECTED}, indent=1, default=str)[:6000])
